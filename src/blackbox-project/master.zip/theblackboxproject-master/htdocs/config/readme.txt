
MAIN CONFIG
1. make a copy of config-main-skel.php
2. change the name to config-main.php
3. edit as appropraite